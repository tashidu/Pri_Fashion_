from django.apps import AppConfig


class CuttingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cutting'
