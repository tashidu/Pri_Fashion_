from django.contrib import admin
from .models import  FabricDefinition, Supplier

admin.site.register( FabricDefinition)
admin.site.register(Supplier)
