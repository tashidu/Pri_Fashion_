default_app_config = 'finished_product.apps.FinishedProductConfig'
